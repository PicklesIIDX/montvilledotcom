namespace Schooner.Test;

using Core;
using Core.ScoreProviders;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class ScoreProviderFactoryTests
{
    private class ScoreProviderFactoryTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(Category.ONES, typeof(MatchingRollProvider), 
                new List<int>() { 1, 1, 2, 2, 3 }, 2)
                .SetName($"When given category {Category.ONES}, and roll with two ones, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 2");
            
            yield return new TestCaseData(Category.TWOS, typeof(MatchingRollProvider), 
                    new List<int>() { 1, 1, 2, 2, 3 }, 4)
                .SetName($"When given category {Category.TWOS}, and roll with two twos, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 4");
            
            yield return new TestCaseData(Category.THREES, typeof(MatchingRollProvider), 
                    new List<int>() { 3, 3, 2, 2, 4 }, 6)
                .SetName($"When given category {Category.THREES}, and roll with two threes, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 6");
            
            yield return new TestCaseData(Category.FOURS, typeof(MatchingRollProvider), 
                    new List<int>() { 4, 4, 2, 2, 3 }, 8)
                .SetName($"When given category {Category.FOURS}, and roll with two fours, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 8");
            
            yield return new TestCaseData(Category.FIVES, typeof(MatchingRollProvider), 
                    new List<int>() { 5, 5, 2, 2, 3 }, 10)
                .SetName($"When given category {Category.FIVES}, and roll with two fives, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 10");
            
            yield return new TestCaseData(Category.SIXES, typeof(MatchingRollProvider), 
                    new List<int>() { 6, 6, 2, 2, 3 }, 12)
                .SetName($"When given category {Category.SIXES}, and roll with two sixes, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 12");
            
            yield return new TestCaseData(Category.SEVENS, typeof(MatchingRollProvider), 
                    new List<int>() { 7, 7, 2, 2, 3 }, 14)
                .SetName($"When given category {Category.SEVENS}, and roll with two sevens, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 14");
            
            yield return new TestCaseData(Category.EIGHTS, typeof(MatchingRollProvider), 
                    new List<int>() { 8, 8, 2, 2, 3 }, 16)
                .SetName($"When given category {Category.EIGHTS}, and roll with two eights, " +
                         $"returns a {nameof(MatchingRollProvider)} with score 16");
            
            yield return new TestCaseData(Category.FULLHOUSE, typeof(FullHouseScoreProvider), 
                    new List<int>() { 1, 1, 2, 2, 2 }, FullHouseScoreProvider.FullHouseScore)
                .SetName($"When given category {Category.FULLHOUSE}, and roll with full house, " +
                         $"returns a {nameof(FullHouseScoreProvider)} with score {FullHouseScoreProvider.FullHouseScore}");

            yield return new TestCaseData(Category.SMALL_STRAIGHT, typeof(StraightScoreProvider), 
                    new List<int>() { 1, 2, 3, 4, 5 }, 30)
                .SetName($"When given category {Category.SMALL_STRAIGHT}, and roll with small straight, " +
                         $"returns a {nameof(StraightScoreProvider)} with score 30");
            
            yield return new TestCaseData(Category.LARGE_STRAIGHT, typeof(StraightScoreProvider), 
                    new List<int>() { 1, 2, 3, 4, 5 }, 40)
                .SetName($"When given category {Category.LARGE_STRAIGHT}, and roll with large straight, " +
                         $"returns a {nameof(StraightScoreProvider)} with score 40");
            
            yield return new TestCaseData(Category.SCHOONER, typeof(MatchingScoreProvider), 
                    new List<int>() { 5, 5, 5, 5, 5 }, 50)
                .SetName($"When given category {Category.SCHOONER}, and roll with 5 matching numbers, " +
                         $"returns a {nameof(MatchingScoreProvider)} with score 50");
            
            yield return new TestCaseData(Category.FOUR_OF_A_KIND, typeof(MatchingScoreProvider), 
                    new List<int>() { 5, 5, 5, 5, 6 }, 26)
                .SetName($"When given category {Category.FOUR_OF_A_KIND}, and roll with 5 matching numbers, " +
                         $"returns a {nameof(MatchingScoreProvider)} with score that is the sum of all numbers");
            
            yield return new TestCaseData(Category.THREE_OF_A_KIND, typeof(MatchingScoreProvider), 
                    new List<int>() { 5, 5, 5, 7, 6 }, 28)
                .SetName($"When given category {Category.THREE_OF_A_KIND}, and roll with 3 matching numbers, " +
                         $"returns a {nameof(MatchingScoreProvider)} with score that is the sum of all numbers");
            
            yield return new TestCaseData(Category.ALL_DIFFERENT, typeof(AllDifferentScoreProvider), 
                    new List<int>() { 5, 2, 1, 3, 8 }, 35)
                .SetName($"When given category {Category.ALL_DIFFERENT}, and roll with 5 different numbers, " +
                         $"returns a {nameof(MatchingScoreProvider)} with score 35");
            
            yield return new TestCaseData(Category.CHANCE, typeof(AlwaysScoreProvider), 
                    new List<int>() { 7, 3, 6, 4, 7 }, 27)
                .SetName($"When given category {Category.CHANCE}, and roll with any numbers, " +
                         $"returns a {nameof(AlwaysScoreProvider)} with score the sum of the numbers");
        }
    }
    
    [TestCaseSource(typeof(ScoreProviderFactoryTestCases), nameof(ScoreProviderFactoryTestCases.TestCases))]
    public void Get(Category category, Type expectedType, List<int> rolls, int expectedScore)
    {
        var factory = new ScoreProviderFactory();
        var provider = factory.Get(category);
        provider.Should().BeOfType(expectedType);
        provider.GetScore(rolls).Should().Be(expectedScore);
    }
}
