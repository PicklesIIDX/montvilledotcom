namespace Schooner.Test;

using Core.Calculators;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class ScoreCalculatorTests
{

    [TestCase(50)]
    [TestCase(0)]
    public void ConstantCalculator_Calculate_ReturnsConstantValue(int expectedScore)
    {
        var calculator = new ConstantCalculator(expectedScore);
        var score = calculator.Calculate(new List<int>());
        score.Should().Be(expectedScore);
    }

    private class SummationTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(new List<int>() { 1, 1, 1, 1, 1 }, 5)
                .SetName("When given 5 1's, returns 5");
            yield return new TestCaseData(new List<int>() { 1, 2, 3, 4, 5 }, 15)
                .SetName("When given straight from 1, returns 15");
        }
    }
    
    [TestCaseSource(typeof(SummationTestCases), nameof(SummationTestCases.TestCases))]
    public void SummationCalculator_Calculate_ReturnsTotalOfAllRolls(List<int> rolls, int expectedScore)
    {
        var calculator = new SummationCalculator();
        var score = calculator.Calculate(rolls);
        score.Should().Be(expectedScore);
    }
}


