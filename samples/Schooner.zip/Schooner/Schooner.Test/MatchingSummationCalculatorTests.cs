namespace Schooner.Test;

using Core.Calculators;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class MatchingSummationCalculatorTests
{
    private class MatchingSummationCalculatorTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(new List<int> { 1, 2, 3, 4, 8 }, 4, 4)
                .SetName("Given one matching number, returns number");
            yield return new TestCaseData(new List<int> { 1, 5, 7, 7, 8 }, 7, 14)
                .SetName("Given multiple matching numbers, returns sum of matched numbers");
            yield return new TestCaseData(new List<int> { 2, 2, 2, 2, 2 }, 2, 10)
                .SetName("Given all matching numbers, returns sum of all numbers");
            yield return new TestCaseData(new List<int> { 1, 2, 3, 7, 8 }, 6, 0)
                .SetName("Given no matching numbers, returns 0");
        }
    }
    
    [TestCaseSource(typeof(MatchingSummationCalculatorTestCases), nameof(MatchingSummationCalculatorTestCases.TestCases))]
    public void Calculate(List<int> rolls, int numberToMatch, int expectedScore)
    {
        var calculator = new MatchingSummationCalculator(numberToMatch);
        var score = calculator.Calculate(rolls);
        score.Should().Be(expectedScore);
    }
}