namespace Schooner.Test;

using System.Collections;
using Core;
using FluentAssertions;
using NUnit.Framework;

public class TopCategoriesTests
{
    private class TopCategoriesTestCases
    {
        public static IEnumerable TestCases
        {
            get
            {
                yield return new TestCaseData(
                    new List<int> { 1, 2, 3, 4, 5 }, 
                    new List<Category> { Category.LARGE_STRAIGHT })
                    .SetName("When given large straight, returns large straight");
                yield return new TestCaseData(
                        new List<int> { 1, 2, 3, 4, 4 }, 
                        new List<Category> { Category.SMALL_STRAIGHT })
                    .SetName("When given small straight that are not all unique, returns small straight");
                yield return new TestCaseData(
                        new List<int> { 1, 3, 4, 5, 6 }, 
                        new List<Category> { Category.ALL_DIFFERENT })
                    .SetName("When given lowest small straight that are all unique, returns all different");
                yield return new TestCaseData(
                        new List<int> { 1, 2, 3, 4, 6 }, 
                        new List<Category> { Category.ALL_DIFFERENT })
                    .SetName("When given all different rolls, returns all different");
                yield return new TestCaseData(
                        new List<int> { 3, 3, 3, 6, 7 }, 
                        new List<Category> { Category.THREE_OF_A_KIND, Category.CHANCE })
                    .SetName("When given three of a kind, returns three of a kind and chance");
                yield return new TestCaseData(
                        new List<int> { 3, 3, 3, 3, 7 }, 
                        new List<Category> { Category.FOUR_OF_A_KIND, Category.THREE_OF_A_KIND, Category.CHANCE })
                    .SetName("When given four of a kind, returns four of a kind, three of a kind, and chance");
                yield return new TestCaseData(
                        new List<int> { 7, 7, 7, 2, 2 },
                        new List<Category> { Category.THREE_OF_A_KIND, Category.FULLHOUSE, Category.CHANCE })
                    .SetName("When given full house with 7s and 2s, returns three of a kind, full house, and chance");
                yield return new TestCaseData(
                        new List<int> { 1, 1, 8, 8, 2 },
                        new List<Category> { Category.CHANCE })
                    .SetName("When given a pair, returns chance because sum of all dice is always higher than sum of two");
                yield return new TestCaseData(
                        new List<int> { 8, 8, 8, 8, 8 },
                        new List<Category> { Category.SCHOONER })
                    .SetName("When given highest five of a kind, returns schooner");
            }
        }
    }
    [TestCaseSource(typeof(TopCategoriesTestCases), nameof(TopCategoriesTestCases.TestCases))]
    public void TopCategories_WhenGivenFullSequence_ReturnsFullStraight(List<int> rolls, List<Category> expectedResult)
    {
        var provider = new TopCategoryProvider();
        var categories = provider.TopCategories(rolls);
        categories.Should().BeEquivalentTo(expectedResult);
    }
}