namespace Schooner.Test;

using Core.Calculators;
using Core.ScoreProviders;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class MatchingRollProviderTests
{
    private class MatchingRollProviderTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(new List<int> { 1, 2, 3, 4, 5 }, 1, 99)
                .SetName("Given a valid roll with ones and one is the number to match, returns expected score");
            yield return new TestCaseData(new List<int> { 1, 1, 1, 4, 5 }, 1, 99)
                .SetName("Given another valid roll with matching number, returns expected score");
            yield return new TestCaseData(new List<int> { 1, 1, 1, 4, 5 }, 4, 99)
                .SetName("Given another valid roll with another matching number, returns expected score");
            yield return new TestCaseData(new List<int> { 2, 3, 4, 4, 5 }, 1, 0)
                .SetName("Given an invalid roll without matching number, returns 0");
        }
    }
    
    [TestCaseSource(typeof(MatchingRollProviderTestCases), nameof(MatchingRollProviderTestCases.TestCases))]
    public void GetScore(List<int> rolls, int numberToMatch, int expectedScore)
    {
        var provider = new MatchingRollProvider(numberToMatch, new ConstantCalculator(expectedScore));
        var score = provider.GetScore(rolls);
        score.Should().Be(expectedScore);
    }
}