namespace Schooner.Test;

using Core.Calculators;
using Core.ScoreProviders;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class MatchingScoreProviderTests
{
    private class MatchingScoreProviderTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(new List<int> { 5, 5, 5, 5, 5 }, 5, 50)
                    .SetName("Given valid Shooner, returns 50");
                yield return new TestCaseData(new List<int> { 5, 5, 5, 5, 4 }, 5, 0)
                    .SetName("Given invalid Shooner with less than 5 matches, returns 0");
                yield return new TestCaseData(new List<int> { 1, 2, 3, 4, 5 }, 5, 0)
                    .SetName("Given invalid Shooner with no matches, returns 0");
                
                yield return new TestCaseData(new List<int> { 1, 1, 1, 1, 8 }, 4, 12)
                    .SetName("Given valid four of a kind, returns sum of all dice");
                yield return new TestCaseData(new List<int> { 8, 8, 8, 8, 2 }, 4, 34)
                    .SetName("Given another valid four of a kind, returns sum of all dice");
                yield return new TestCaseData(new List<int> { 8, 8, 8, 2, 2 }, 4, 0)
                    .SetName("Given invalid four of a kind with fewer than four matches, returns 0");
                yield return new TestCaseData(new List<int> { 8, 8, 8, 8, 8 }, 4, 40)
                    .SetName("Given a valid four of a kind with five matches, returns sum of all dice");
                
                yield return new TestCaseData(new List<int> { 3, 3, 3, 2, 2 }, 3, 13)
                    .SetName("Given valid three of a kind, returns sum of all dice");
                yield return new TestCaseData(new List<int> { 6, 6, 6, 4, 4 }, 3, 26)
                    .SetName("Given another valid three of a kind, returns sum of all dice");
                yield return new TestCaseData(new List<int> { 3, 3, 1, 2, 2 }, 3, 0)
                    .SetName("Given invalid three of a kind with fewer than three matches, returns 0");
                yield return new TestCaseData(new List<int> { 3, 3, 3, 3, 3 }, 3, 15)
                    .SetName("Given a valid three of a kind with five matches, returns sum of all dice");
        }
    }
    
    [TestCaseSource(typeof(MatchingScoreProviderTestCases), nameof(MatchingScoreProviderTestCases.TestCases))]
    public void GetScore(List<int> rolls, int requiredMatches, int expectedScore)
    {
        var provider = new MatchingScoreProvider(requiredMatches, new ConstantCalculator(expectedScore));
        var score = provider.GetScore(rolls);
        score.Should().Be(expectedScore);
    }
}