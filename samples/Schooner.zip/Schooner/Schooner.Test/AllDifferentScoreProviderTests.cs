namespace Schooner.Test;

using Core.ScoreProviders;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class AllDifferentScoreProviderTests
{
    private class AllDifferentTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(new List<int>() { 1, 2, 3, 4, 5 }, 50)
                .SetName("When given all different rolls, returns expected score");
            yield return new TestCaseData(new List<int>() { 4, 5, 6, 7, 2 }, 50)
                .SetName("When given other all different rolls, returns expected score");
            yield return new TestCaseData(new List<int>() { 1, 1, 3, 4, 5 }, 0)
                .SetName("When given any matching rolls, returns 0");
        }
    }
    
    [TestCaseSource(typeof(AllDifferentTestCases), nameof(AllDifferentTestCases.TestCases))]
    public void GetScore(List<int> rolls, int expectedScore)
    {
        var provider = new AllDifferentScoreProvider(expectedScore);
        var score = provider.GetScore(rolls);
        score.Should().Be(expectedScore);
    }
}