namespace Schooner.Test;

using Core.ScoreProviders;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class StraightScoreProviderTests
{
    private class StraightScoreProviderTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(new List<int> { 1, 2, 3, 4, 8 }, 4, 30)
                .SetName("Given valid small straight with straight size 4, returns 30");
            yield return new TestCaseData(new List<int> { 1, 5, 6, 7, 8 }, 4, 30)
                .SetName("Given another valid small straight with straight size 4, returns 30");
            yield return new TestCaseData(new List<int> { 4, 2, 3, 8, 5 }, 4, 30)
                .SetName("Given valid unsorted small straight with straight size 4, returns 30");
            yield return new TestCaseData(new List<int> { 1, 2, 3, 7, 8 }, 4, 0)
                .SetName("Given straight with fewer sequential than the straight size, returns 0");
                
            yield return new TestCaseData(new List<int> { 1, 2, 3, 4, 5 }, 5, 40)
                .SetName("Given valid large straight with straight size 5, returns 40");
            yield return new TestCaseData(new List<int> { 1, 2, 3, 4, 6 }, 5, 0)
                .SetName("Given invalid large straight with straight size 5, returns 0");
        }
    }
    
    [TestCaseSource(typeof(StraightScoreProviderTestCases), nameof(StraightScoreProviderTestCases.TestCases))]
    public void GetScore(List<int> rolls, int straightSize, int expectedScore)
    {
        var provider = new StraightScoreProvider(straightSize, expectedScore);
        var score = provider.GetScore(rolls);
        score.Should().Be(expectedScore);
    }
}