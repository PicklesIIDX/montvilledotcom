namespace Schooner.Test;

using Core.ScoreProviders;
using FluentAssertions;
using NUnit.Framework;

[TestFixture]
public class FullHouseScoreProviderTests
{
    private class FullHouseScoreProviderTestCases
    {
        public static IEnumerable<TestCaseData> TestCases()
        {
            yield return new TestCaseData(new List<int> { 1, 1, 1, 7, 7 }, FullHouseScoreProvider.FullHouseScore)
                .SetName($"Given Valid Full House, returns {nameof(FullHouseScoreProvider.FullHouseScore)}");
            yield return new TestCaseData(new List<int> { 1, 1, 1, 7, 6 }, 0)
                .SetName("Given Invalid Full House with 3 values, returns 0");
            yield return new TestCaseData(new List<int> { 1, 1, 1, 1, 6 }, 0)
                .SetName("Given Invalid Full House with 4 of a kind, returns 0");
        }
    }
    
    [TestCaseSource(typeof(FullHouseScoreProviderTestCases), nameof(FullHouseScoreProviderTestCases.TestCases))]
    public void GetScore(List<int> rolls, int expectedScore)
    {
        var provider = new FullHouseScoreProvider();
        var score = provider.GetScore(rolls);
        score.Should().Be(expectedScore);
    }
}