﻿using Schooner.Core;

ScoreProvider scoreProvider = new ScoreProvider();
var score = scoreProvider.Score(Category.ONES, new List<int>(){1,2,3,4,5});

Console.WriteLine(score);

TopCategoryProvider topCategoryProvider = new TopCategoryProvider();
var categories = topCategoryProvider.TopCategories(new List<int>(){1, 2, 3, 4, 5});

Console.WriteLine(string.Join(", ", categories));