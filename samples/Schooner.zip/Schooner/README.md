# Schooner
A library to score rounds of a game of Schooner.

# Requirements
[.NET 8.0](https://dotnet.microsoft.com/en-us/download/dotnet/8.0)

# Use
Reference `Schooner.Core` in your project either through 
this project directly, or through a built dll (see below).
For information on how to manage references please refer 
to the [MSBuild documentation](https://learn.microsoft.com/en-us/dotnet/core/tools/dependencies).

Reference the Schooner.CLI console application for an example
using the library.

Schooner.Core provides two methods for use in your project:

## Score
Returns a score given a category and a list of dice rolls.

```
var scoreProvider = new Schooner.Core.ScoreProvider();
int score = scoreProvider.Score(category, rolls);
````

`category` must be one of the entries in the Schooner.Core.Category enum.

`rolls` must be a list of 5 integers between 1 and 8 (inclusive).

## TopCategories
Returns a list of the highest scoring categories for the given rolls.

```
var categoryProvider = new Schooner.Core.TopCategoryProvider();
List<Category> categories = categoryProvider.TopCategories(rolls); 
```

`rolls` must be a list of 5 integers between 1 and 8 (inclusive).

# Building

Install the [.NET 8.0 SDK](https://dotnet.microsoft.com/en-us/download/dotnet/8.0)

Navigate to the root directory of this solution.

Run `dotnet build`

# Testing

If you can successfully build the project you can follow up by running
all tests. Navigate to the root directory of this solution.

Run `dotnet test`

# Approach

I Used TDD to find my way to this point. Please look at
the included git repo to see my decisions along the course
of this project. I started fairly simple, but refactored
as each section became repetitive. I think there are more
opportunities to provide more coverage for the ScoreProviderFactory,
but I didn't want to couple too tightly to that implementation.
So I left the coverage to the ScoreProviders and Calculators.

Since there were no performance requirements, I have taken liberty 
to implement this with a fairly heavy OOP approach, favoring a thin API,
testability, and maintainability. The assumption was that this code
would run on a relatively powerful client (any mid-range mobile 
or desktop device) and calculate scores/categories in response 
to a single user's input.