namespace Schooner.Core;

public enum Category
{
    ONES = 1,
    TWOS = 2,
    THREES = 3,
    FOURS = 4,
    FIVES = 5,
    SIXES = 6,
    SEVENS = 7,
    EIGHTS = 8,
    THREE_OF_A_KIND = 9,
    FOUR_OF_A_KIND = 10,
    FULLHOUSE = 11,
    SMALL_STRAIGHT = 12,
    ALL_DIFFERENT = 13,
    LARGE_STRAIGHT = 14,
    SCHOONER = 15,
    CHANCE = 16,
}
