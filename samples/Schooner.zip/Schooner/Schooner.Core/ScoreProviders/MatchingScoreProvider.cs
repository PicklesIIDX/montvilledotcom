namespace Schooner.Core.ScoreProviders;

using Calculators;

internal class MatchingScoreProvider : IScoreProvider
{
    private readonly int _requiredMatches;
    private readonly IScoreCalculator _calculator;

    public MatchingScoreProvider(int requiredMatches, IScoreCalculator calculator)
    {
        _requiredMatches = requiredMatches;
        _calculator = calculator;
    }

    public int GetScore(List<int> rolls)
    {
        var countTable = new int[8];
        foreach (var roll in rolls)
        {
            countTable[roll - 1]++;
        }

        if (countTable.Any(count => count >= _requiredMatches))
        {
            return _calculator.Calculate(rolls);
        }

        return 0;
    }
}