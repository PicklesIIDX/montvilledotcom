namespace Schooner.Core.ScoreProviders;

using Calculators;

internal class MatchingRollProvider : IScoreProvider
{
    private readonly int _numberToMatch;
    private readonly IScoreCalculator _calculator;

    public MatchingRollProvider(int numberToMatch, IScoreCalculator calculator)
    {
        _numberToMatch = numberToMatch;
        _calculator = calculator;
    }

    public int GetScore(List<int> rolls)
    {
        var matchingRolls = rolls.Where(r => r == _numberToMatch);
        var matchArray = matchingRolls as int[] ?? matchingRolls.ToArray();
        if (matchArray.Length == 0)
        {
            return 0;
        }

        return _calculator.Calculate(rolls);
    }
}