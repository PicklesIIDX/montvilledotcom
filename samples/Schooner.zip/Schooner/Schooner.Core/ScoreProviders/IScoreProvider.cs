using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Schooner.Test")]
namespace Schooner.Core.ScoreProviders;

internal interface IScoreProvider
{
    int GetScore(List<int> rolls);
}