namespace Schooner.Core.ScoreProviders;

internal class AllDifferentScoreProvider : IScoreProvider
{
    private readonly int _score;

    public AllDifferentScoreProvider(int score)
    {
        _score = score;
    }

    public int GetScore(List<int> rolls)
    {
        if (rolls.Distinct().Count() != rolls.Count)
        {
            return 0;
        }

        return _score;
    }
}