namespace Schooner.Core.ScoreProviders;

using Calculators;

internal class AlwaysScoreProvider : IScoreProvider
{
    private readonly IScoreCalculator _calculator;

    public AlwaysScoreProvider(IScoreCalculator calculator)
    {
        _calculator = calculator;
    }


    public int GetScore(List<int> rolls)
    {
        return _calculator.Calculate(rolls);
    }
}