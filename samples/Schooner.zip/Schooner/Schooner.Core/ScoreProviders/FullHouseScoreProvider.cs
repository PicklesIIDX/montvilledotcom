namespace Schooner.Core.ScoreProviders;

internal class FullHouseScoreProvider : IScoreProvider
{
    public const int FullHouseScore = 25;
    public int GetScore(List<int> rolls)
    {
        var uniqueEntries = new HashSet<int>();
        var countOfFirstEntry = 0;
        var firstEntry = rolls[0];
        foreach (var roll in rolls)
        {
            uniqueEntries.Add(roll);
            if (roll == firstEntry)
            {
                countOfFirstEntry++;
            }
        }

        if (uniqueEntries.Count != 2
            || (countOfFirstEntry != 2 && countOfFirstEntry != 3))
        {
            return 0;
        }
        return 25;
    }
}