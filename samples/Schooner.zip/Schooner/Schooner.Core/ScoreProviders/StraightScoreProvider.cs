namespace Schooner.Core.ScoreProviders;

internal class StraightScoreProvider : IScoreProvider
{
    private readonly int _straightSize;
    private readonly int _score;

    public StraightScoreProvider(int straightSize, int score)
    {
        _straightSize = straightSize;
        _score = score;
    }
    public int GetScore(List<int> rolls)
    {
        rolls.Sort();
        var sequentialCount = 1;
        for (var i = 1; i < rolls.Count; i++)
        {
            var roll = rolls[i];
            var previous = rolls[i-1];
            if (roll == previous + 1)
            {
                sequentialCount++;
                if (sequentialCount == _straightSize)
                {
                    break;
                }
                continue;
            }
            sequentialCount = 1;
        }

        if (sequentialCount != _straightSize)
        {
            return 0;
        }

        return _score;
    }
}