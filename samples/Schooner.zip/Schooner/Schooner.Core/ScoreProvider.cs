﻿namespace Schooner.Core;

public class ScoreProvider
{
    private readonly ScoreProviderFactory _scoreProviderFactory;

    public ScoreProvider()
    {
        _scoreProviderFactory = new ScoreProviderFactory();
    }
    
    /// <summary>
    /// Use this to score a roll in a game of Schooner.
    /// </summary>
    /// <param name="category">The category to qualify the provided rolls.</param>
    /// <param name="rolls">Rolls of 8 sided dice. Values must be within 1 to 8
    /// (inclusive). Must contain exactly 5 entries.</param>
    /// <returns>Returns the score for the given rolls if it
    /// is valid for the given category. Returns 0 if the
    /// roll does not qualify for the given category.</returns>
    /// <exception cref="ArgumentException">Thrown if the category is not handled.</exception>
    public int Score(Category category, List<int> rolls)
    {
        return _scoreProviderFactory.Get(category).GetScore(rolls);
    }
}