namespace Schooner.Core;

public class TopCategoryProvider
{
    /// <summary>
    /// Use this to provide the top scoring <see cref="Category"/> for a given
    /// roll in the game of Schooner.
    /// </summary>
    /// <param name="roll">Rolls of 8 sided dice. Values must be within 1 to 8
    /// (inclusive). Must contain exactly 5 entries.</param>
    /// <returns>A list of <see cref="Category"/> that qualify with the given roll
    /// and provide the highest possible score for the given roll.</returns>
    public List<Category> TopCategories(List<int> roll)
    {
        var scoreProvider = new ScoreProvider();
        var categories = Enum.GetValuesAsUnderlyingType<Category>() as Category[];
        if (categories == null) { return new List<Category>();}
        var highestScoringEntries = new List<Category>();
        var highestScore = 0;
        foreach (var category in categories)
        {
            var score = scoreProvider.Score(category, roll);
            if (score < highestScore)
            {
                continue;
            }
            if (score > highestScore)
            {
                highestScore = score;
                highestScoringEntries.Clear();
            }
            highestScoringEntries.Add(category);
        }
        return highestScoringEntries;
    }
}