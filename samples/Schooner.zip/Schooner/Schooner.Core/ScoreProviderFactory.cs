namespace Schooner.Core;

using Calculators;
using ScoreProviders;

internal class ScoreProviderFactory
{
    public IScoreProvider Get(Category category)
    {
        switch (category)
        {
            case Category.ONES:
                return new MatchingRollProvider(1, new MatchingSummationCalculator(1));
            case Category.TWOS:
                return new MatchingRollProvider(2, new MatchingSummationCalculator(2));
            case Category.THREES:
                return new MatchingRollProvider(3, new MatchingSummationCalculator(3));
            case Category.FOURS:
                return new MatchingRollProvider(4, new MatchingSummationCalculator(4));
            case Category.FIVES:
                return new MatchingRollProvider(5, new MatchingSummationCalculator(5));
            case Category.SIXES:
                return new MatchingRollProvider(6, new MatchingSummationCalculator(6));
            case Category.SEVENS:
                return new MatchingRollProvider(7, new MatchingSummationCalculator(7));
            case Category.EIGHTS:
                return new MatchingRollProvider(8, new MatchingSummationCalculator(8));
            case Category.FULLHOUSE:
                return new FullHouseScoreProvider();
            case Category.SMALL_STRAIGHT:
                return new StraightScoreProvider(4, 30);
            case Category.LARGE_STRAIGHT:
                return new StraightScoreProvider(5, 40);
            case Category.SCHOONER:
                return new MatchingScoreProvider(5, new ConstantCalculator(50));
            case Category.FOUR_OF_A_KIND:
                return new MatchingScoreProvider(4, new SummationCalculator());
            case Category.THREE_OF_A_KIND:
                return new MatchingScoreProvider(3, new SummationCalculator());
            case Category.ALL_DIFFERENT:
                return new AllDifferentScoreProvider(35);
            case Category.CHANCE:
                return new AlwaysScoreProvider(new SummationCalculator());
        }
        
        throw new ArgumentException($"No {nameof(IScoreProvider)} for {nameof(Category)} '{category}'");
    }
}