namespace Schooner.Core.Calculators;

internal class ConstantCalculator : IScoreCalculator
{
    private readonly int _score;

    public ConstantCalculator(int score)
    {
        _score = score;
    }
    public int Calculate(IEnumerable<int> rolls)
    {
        return _score;
    }
}