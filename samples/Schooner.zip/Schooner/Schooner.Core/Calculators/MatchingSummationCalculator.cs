namespace Schooner.Core.Calculators;

internal class MatchingSummationCalculator : IScoreCalculator
{
    private readonly int _numberToMatch;

    public MatchingSummationCalculator(int numberToMatch)
    {
        _numberToMatch = numberToMatch;
    }
    public int Calculate(IEnumerable<int> rolls)
    {
        var matchingRolls = rolls.Where(r => r == _numberToMatch);
        return matchingRolls.Sum();
    }
}