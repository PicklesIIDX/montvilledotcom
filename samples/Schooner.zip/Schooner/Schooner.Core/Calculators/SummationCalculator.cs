namespace Schooner.Core.Calculators;

internal class SummationCalculator: IScoreCalculator
{
    public int Calculate(IEnumerable<int> rolls)
    {
        return rolls.Sum();
    }
}