using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Schooner.Test")]
namespace Schooner.Core.Calculators;

internal interface IScoreCalculator
{
    int Calculate(IEnumerable<int> rolls);
}